</head>
<body>
	<div id="wrapper">
        <ul id="mainNav">
        	<li><a class="active">Viral Media Portal : Installation Wizard</a></li> <!-- Use the "active" class for the active menu item  -->
        	<li class="logout"><a href="http://www.nexthon.com">Nexthon</a></li>
        </ul>